{pkgs}: {
  deps = [
    pkgs.git
    pkgs.dotnet-sdk_8
  ];
}
